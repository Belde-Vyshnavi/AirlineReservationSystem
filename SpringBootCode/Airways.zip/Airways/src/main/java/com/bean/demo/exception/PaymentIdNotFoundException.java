package com.bean.demo.exception;

public class PaymentIdNotFoundException extends Exception{
	public PaymentIdNotFoundException(String message) {
		super(message);
	}

}
