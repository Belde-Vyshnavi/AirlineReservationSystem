import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Booking } from '../class/booking';
import { Userair } from '../class/userair';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private addBookingurl="http://localhost:8080/booking/bookflight";
  private bookingbyidurl="http://localhost:8080/booking/getBooking";
  private bookinglisturl="http://localhost:8080/booking/viewBooking";
  private updateBookingurl="http://localhost:8080/booking/updateBooking";
  private deleteBookingurl="http://localhost:8080/booking/deleteBooking";
  constructor(private http:HttpClient) { }

  viewAllBookings():Observable<any>
  {
    return this.http.get(this.bookinglisturl);
   }
/*
SaveBooking(booking:Booking,flightId:number,seatsToBook:number):Observable<any>{
  
  const headers={'content-type':'application/json'};
  const body=JSON.stringify(seatsToBook);
  return this.http.post(this.addBookingurl,booking,{'headers':headers})
}
*/
   SaveBooking(booking:Booking):Observable<any>
   {
     const httpOptions = {
       headers : new HttpHeaders({
           'Content-Type' : 'application/json',
           'Authorization' : 'auth-token',
           'Access-Control-Allow-Origin' : '*'
       })
     };
     return  this.http.post<Booking>(this.addBookingurl,booking,httpOptions);
   }

  
   deleteBooking(booking_id: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'auth-token',
        'Access-Control-Allow-Origin': '*'
      })
    };
  
    return this.http.delete<Booking>(`${this.deleteBookingurl}/${booking_id}`, httpOptions);
  }


  updateBooking(booking:Booking):Observable<any>
  {
    const headers={'content-type':'application/json'};
    const body=JSON.stringify(booking);
    return this.http.put(this.updateBookingurl,body,{'headers':headers});
  }


  getBookingById(booking_id: number) {
    const bookingidurl=this.bookingbyidurl+"/"+booking_id;
    return this.http.get<Booking>(bookingidurl);
  }

  
}
