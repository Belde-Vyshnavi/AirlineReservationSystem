import { Component } from '@angular/core';
import { BookingService } from '../../service/booking.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewallbookings',
  templateUrl: './viewallbookings.component.html',
  styleUrl: './viewallbookings.component.css'
})
export class ViewallbookingsComponent {
  booking:any;
  constructor(private bookingService:BookingService,private router:Router,private activateRoute:ActivatedRoute){}
   
ngOnInit():void{
  this.viewAllBookings();
}



viewAllBookings():void
{ 
this.bookingService.viewAllBookings().subscribe(data=>{
  console.log(data);
  this.booking=data;
})
}


homepage():void{
  this.router.navigateByUrl("/adminhome");
}
}
