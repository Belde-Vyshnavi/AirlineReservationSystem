import { Employeeair } from './employeeair';

describe('Employeeair', () => {
  it('should create an instance', () => {
    expect(new Employeeair()).toBeTruthy();
  });
});
